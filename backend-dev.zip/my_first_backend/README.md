# Welcome to My First Backend
***

## Task
The task was to create a backend app with light web framework. In this app, I used express js. There was no need to create a database, the code was stored in a plain file.
The app have a route GET on /. This app gives randomly selected songs from a list of least 20 songs from Frank Sinatra's genre.

## Description
The app has a route GET on /. This app gives randomly selected songs from a list of least 20 songs from Frank Sinatra's genre.
The app also has a route GET on /birth_date. This action will give Frank Sinatra birth date.
The app also has a route GET on /birth_city. This action will give Frank Sinatra birth city.
The app also has a route GET GET on /wives. This action will give all the name of Frank Sinatra wife with the format of; wife1, wife2, wife3, wife4...
The app also has a route GET on /public. This action will print "Everybody can see this page"
The app also has a route GET on /protected. This action will be protected by a HTTP Basic access authentication and print "Welcome, authenticated client" if you are authorized with the login admin and password admin otherwise it will provide a 401 Not authorized.

## Installation
The will be installed with a npm package JSON.
The package.json file, replace the contents of the "scripts" with "create": "node ./services/dbConnect createTables". We will use this to execute the dbConnect file we are about to create.

## Usage
Get into your server on port 8080 or port = 8080, but you and listen on 0.0.0.0
The server will be accessible at this URL using the HTTP Codes 200, 204, 400, 401, 500 and the HTTP Basic access authentication.