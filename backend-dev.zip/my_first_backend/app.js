// const express = require('express')
// const app = express()
// const port = 8080


// app.get('/', (req, res) => {
//         sinatra_songs = ["The Man in the Looking Glass", "Marie", "Maybe This Time", "Accidents Will Happen", 
//         "Ad-Lib Blues", "Ain't Cha Ever Comin' Back?", "Air For English Horn", "All I Need is the Girl", 
//         "All My Tomorrows", "All of Me", "All of You", "All or Nothing at All", "All Through the Day", 
//         "All This and Heaven Too", "All the Way Home", "And Then You Kissed Me", "Anything", 
//         "Anytime I'll Be There", "Anytime, Anywhere", "Any Time at All"];

//         randomsongs = sinatra_songs[Math.floor(Math.random(" ") * sinatra_songs.length)];
//         res.send(randomsongs);
    
//         random_index = getRandomValueWithinRange(0, sinatra_songs.length);
        
//         return (sinatra_songs[random_index]);
    
// })

// // frank sinatra date of birth
// app.get("/birth_date", (req, res)=> {
//     sinatra_birthday = "December 12, 1915";
//     //you can just insert date directly inside of "res.send()"
//     res.send(sinatra_birthday);
// })



// app.get('/protected', (req, res) => {
//     // console.log(req.headers.authorization);
//     // console.log(req.headers.authorization.split(' ')[1]);

//     array = atob(req.headers.authorization.split.split(' ')[1]).split(':');
//     username = array[0];
//     password = array[1];

//     if (username == 'admin' && password == 'admin'){
//         res.send('Welcome, authenticated client');
//     }

//     res.set('WWW-Authenicate', 'Basic realm="401"');
//     res.status(401).send('Not authorized');
// })



// app.listen(port, '0.0.0.0', () => {
//     console.log("server started " + port);
// })







const express = require('express');
const app = express();
const port = 8080;


const basicAuthentication = require('express-basic-auth')


app.get("/", (req, res)=> {
    sinatra_songs = ["Accidents will happen", "All By Myself", "All I Do Is Dream of You", "Blame it on my youth", "All My Tomorrows", "All of Me", "All of You", "Blue Hawaii", "All the Things You Are", "Bonita", "All the Way Home", "All This and Heaven Too", "Can i steal a little love", "Almost Like Being in Love", "Always", "America the Beautiful", "American Beauty Rose", 
    "The boys night out", "Anything", "Barbara"];
    randomsongs = sinatra_songs[Math.floor(Math.random(" ") * sinatra_songs.length)];
    res.send(randomsongs);
})

app.get("/birth_date", (req, res)=> {
    sinatra_birthday = "December 12, 1915";
    //you can just insert date directly inside of "res.send()"
    res.send(sinatra_birthday);
})

app.get("/birth_city", (req, res)=> {
    frankbirthcity= "Hoboken, New Jersey";
     //you can just insert city and state directly inside of "res.send()"
    res.send(frankbirthcity);
})

app.get("/wives", (req, res)=> {
    res.send("Nancy Barbato, Ava Gardner, Mia Farrow, Barbara Marx")
})
app.get("/picture", (req, res)=> {
    res.redirect("https://upload.wikimedia.org/wikipedia/commons/a/af/Frank_Sinatra_%2757.jpg");
})

app.get("/public", (req, res)=> {
    res.send("Everybody can see this page")
})

app.use("/protected", basicAuthentication({
    users: { 'admin': 'admin' },
    challenge: true,
    unauthorizedResponse: 'Not authorized',
}))


app.get("/protected", (req, res)=> {
    res.send("Welcome, authenticated client")
})

// app.listen(port, ()=> console.log("listening on port" + port))

app.listen(port, '0.0.0.0', () => {
    console.log("server started " + port);
})